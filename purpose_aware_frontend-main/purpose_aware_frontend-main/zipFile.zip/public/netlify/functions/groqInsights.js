export async function handler(event, context) {
  const GROQ_API_KEY = process.env.GROQ_API_KEY;
  
  if (!GROQ_API_KEY) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'GROQ_API_KEY not configured' })
    };
  }

  try {
    const body = JSON.parse(event.body);
    const { bioHardware, internalOS, culturalSoftware, socialInstance, consciousUser } = body;

    const allLayers = [bioHardware, internalOS, culturalSoftware, socialInstance, consciousUser];
    const avgScore = (allLayers.reduce((a, b) => a + b, 0) / allLayers.length).toFixed(2);
    
    const layerNames = ['Your Body & Health', 'Your Inner Beliefs', 'Your Values & Worldview', 'Your Daily Life', 'Your Self-Awareness'];
    const bottleneckIndex = allLayers.indexOf(Math.min(...allLayers));
    const bottleneck = layerNames[bottleneckIndex];

    const prompt = `You are a friendly life coach explaining things in simple, everyday language. Avoid jargon.

Here's how someone rates their life across 5 core areas (scored 1-10):

1. YOUR BODY & HEALTH (score: ${bioHardware})
   - Sleep, exercise, nutrition, energy levels, physical fitness

2. YOUR INNER BELIEFS (score: ${internalOS})
   - Self-confidence, how you talk to yourself, past trauma healing, feeling worthy and safe

3. YOUR VALUES & WORLDVIEW (score: ${culturalSoftware})
   - What you believe matters in life, your principles, what drives your decisions

4. YOUR DAILY LIFE (score: ${socialInstance})
   - Your job, relationships, where you live, how you spend your time, your financial situation

5. YOUR SELF-AWARENESS (score: ${consciousUser})
   - How much you notice what's happening in your life, your ability to make conscious choices, feeling in control

Overall health score: ${avgScore}/10
Weakest area right now: ${bottleneck}

Give 3-4 practical, friendly suggestions. Focus on the weakest area first. Use real-world examples, not theory. Keep it short and actionable. Speak like you're talking to a friend.`;

    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${GROQ_API_KEY}`
      },
      body: JSON.stringify({
        model: 'mixtral-8x7b-32768',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 600,
        temperature: 0.7
      })
    });

    if (!response.ok) {
      throw new Error(`Groq API error: ${response.status}`);
    }

    const data = await response.json();
    const insights = data.choices[0]?.message?.content || null;

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ insights })
    };
  } catch (err) {
    console.error('Groq insights error:', err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
}
