export async function handler(event, context) {
  const GROQ_API_KEY = process.env.GROQ_API_KEY;
  
  if (!GROQ_API_KEY) {
    return { statusCode: 500, body: JSON.stringify({ error: 'GROQ_API_KEY not configured' }) };
  }

  try {
    const { scenario, assessmentData } = JSON.parse(event.body);

    const layerScores = `
Assessment Scores (1-10):
- Body & Health: ${assessmentData.bioHardware}
- Inner Beliefs: ${assessmentData.internalOS}
- Values & Worldview: ${assessmentData.culturalSoftware}
- Daily Life: ${assessmentData.socialInstance}
- Self-Awareness: ${assessmentData.consciousUser}`;

    const systemPrompt = `You are a diagnostic coach using the Akorfa Stack Framework. When someone describes a problem, you:
1. Identify which of the 5 life layers are contributing to it
2. Show how they interact and make the problem worse
3. Provide 4-5 specific, concrete action steps to fix it
4. Use everyday language, not theory

The 5 layers are:
- Body & Health: Sleep, exercise, nutrition, energy
- Inner Beliefs: Self-talk, confidence, trauma recovery, feeling worthy
- Values & Worldview: What matters to you, your principles
- Daily Life: Job, relationships, environment, money
- Self-Awareness: Noticing what's happening, making conscious choices

You MUST respond ONLY with valid JSON in this exact format (no markdown, no code blocks):
{
  "summary": "Brief explanation of what's happening and why",
  "rootCauses": [
    {
      "layer": "Layer name",
      "explanation": "How this layer is contributing to the problem"
    }
  ],
  "actionSteps": [
    {
      "action": "Specific action title",
      "description": "How to do it and why it matters",
      "timeline": "When to do it (e.g., 'This week', 'Starting tomorrow', 'Daily')"
    }
  ],
  "whyItHelps": "Brief explanation of how fixing these things will solve the problem"
}`;

    const userPrompt = `My situation: ${scenario}

${layerScores}

Please diagnose which layers are involved and give me concrete steps to improve.`;

    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${GROQ_API_KEY}`
      },
      body: JSON.stringify({
        model: 'mixtral-8x7b-32768',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        max_tokens: 1200,
        temperature: 0.7
      })
    });

    if (!response.ok) {
      throw new Error(`Groq API error: ${response.status}`);
    }

    const data = await response.json();
    const responseText = data.choices[0]?.message?.content || '';

    let diagnosis;
    try {
      diagnosis = JSON.parse(responseText);
    } catch (e) {
      console.error('Failed to parse response:', responseText);
      diagnosis = {
        summary: responseText,
        rootCauses: [{ layer: 'Multiple', explanation: 'Your situation involves interconnected life areas' }],
        actionSteps: [
          { action: 'Start with self-awareness', description: 'Take time to notice which areas feel most broken', timeline: 'This week' },
          { action: 'Pick one area to focus on first', description: 'Usually your lowest-scoring layer', timeline: 'This week' },
          { action: 'Take one small action in that area', description: 'Just one thing. Build momentum.', timeline: 'Starting tomorrow' }
        ],
        whyItHelps: 'When you fix one layer, the others improve too. Start with the weakest link.'
      };
    }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ diagnosis })
    };
  } catch (err) {
    console.error('Diagnosis error:', err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
}
