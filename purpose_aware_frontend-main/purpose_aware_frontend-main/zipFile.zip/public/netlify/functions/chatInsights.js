export async function handler(event, context) {
  const GROQ_API_KEY = process.env.GROQ_API_KEY;
  
  if (!GROQ_API_KEY) {
    return { statusCode: 500, body: JSON.stringify({ error: 'GROQ_API_KEY not configured' }) };
  }

  try {
    const { message, assessmentData, conversationHistory } = JSON.parse(event.body);
    
    const layerDescriptions = `
    Based on their assessment (rated 1-10 for each):
    - Body & Health: ${assessmentData.bioHardware}
    - Inner Beliefs: ${assessmentData.internalOS}
    - Values & Worldview: ${assessmentData.culturalSoftware}
    - Daily Life: ${assessmentData.socialInstance}
    - Self-Awareness: ${assessmentData.consciousUser}`;

    const conversationContext = conversationHistory.map(m => 
      `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`
    ).join('\n\n');

    const systemPrompt = `You are a supportive coach helping someone understand and improve their life using the Akorfa Stack Framework—5 interconnected areas of life that all affect each other.

${layerDescriptions}

Your job is to:
1. Help them understand what their scores mean
2. Show how different layers affect each other
3. Give concrete, actionable steps to improve
4. Use everyday language, not jargon
5. Focus on their specific situation and goals
6. Always tie advice back to the framework and their scores

Be warm, encouraging, and practical. Ask clarifying questions when needed.`;

    const messages = [
      { role: 'system', content: systemPrompt },
      ...conversationHistory.map(m => ({ role: m.role, content: m.content })),
      { role: 'user', content: message }
    ];

    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${GROQ_API_KEY}`
      },
      body: JSON.stringify({
        model: 'mixtral-8x7b-32768',
        messages: messages,
        max_tokens: 800,
        temperature: 0.7
      })
    });

    if (!response.ok) {
      throw new Error(`Groq API error: ${response.status}`);
    }

    const data = await response.json();
    const aiResponse = data.choices[0]?.message?.content || 'I couldn\'t generate a response. Try rephrasing your question.';

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ response: aiResponse })
    };
  } catch (err) {
    console.error('Chat error:', err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
}
