import React, { useState } from 'react';
import { BarChart, Bar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Info } from 'lucide-react';

const layerInfo = {
  bioHardware: {
    title: '🧬 Body & Health',
    description: 'Your physical foundation. Without good sleep, exercise, and nutrition, everything else breaks down.',
    tips: ['Get 7-9 hours of sleep', 'Exercise 3-4 times per week', 'Eat mostly whole foods', 'Stay hydrated']
  },
  internalOS: {
    title: '⚙️ Inner Beliefs',
    description: 'How you talk to yourself matters. Your subconscious beliefs run your life. Heal trauma, build confidence.',
    tips: ['Notice negative self-talk', 'Practice self-compassion', 'Consider therapy if needed', 'Journal regularly']
  },
  culturalSoftware: {
    title: '🌐 Values & Worldview',
    description: 'What do you actually believe matters? Not what society told you, but what YOU believe.',
    tips: ['Write down your core values', 'Notice where you compromise them', 'Read diverse perspectives', 'Reflect on your principles']
  },
  socialInstance: {
    title: '👥 Daily Life',
    description: 'This is where everything happens. Your job, relationships, environment, money—they\'re all part of your daily stack.',
    tips: ['Audit your environment', 'Evaluate your relationships', 'Review your job satisfaction', 'Check your financial health']
  },
  consciousUser: {
    title: '💡 Self-Awareness',
    description: 'Can you notice what\'s happening? Can you make conscious choices? Or are you on autopilot?',
    tips: ['Practice meditation', 'Notice your reactions before responding', 'Make intentional choices', 'Reflect on your patterns']
  }
};

const LayerPopup = ({ layer, onClose }) => {
  if (!layer) return null;
  const info = layerInfo[layer];
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-slate-800 rounded-2xl max-w-md p-8 border border-purple-500">
        <div className="flex items-start justify-between mb-4">
          <h2 className="text-2xl font-bold">{info.title}</h2>
          <button onClick={onClose} className="text-2xl text-gray-400 hover:text-white">×</button>
        </div>
        <p className="text-gray-300 mb-6">{info.description}</p>
        <div>
          <h3 className="font-semibold mb-3">Ways to Improve:</h3>
          <ul className="space-y-2">
            {info.tips.map((tip, i) => (
              <li key={i} className="text-sm text-gray-300 flex items-start gap-2">
                <span className="text-purple-400 mt-0.5">✓</span>
                {tip}
              </li>
            ))}
          </ul>
        </div>
        <button 
          onClick={onClose}
          className="w-full mt-6 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg font-semibold transition"
        >
          Got it
        </button>
      </div>
    </div>
  );
};

const ModernAssessment = ({ assessmentData, setAssessmentData, purpose }) => {
  const [selectedLayer, setSelectedLayer] = useState(null);
  const { bioHardware = 5, internalOS = 5, culturalSoftware = 5, socialInstance = 5, consciousUser = 5 } = assessmentData || {};

  const updateValue = (key, value) => {
    setAssessmentData({ ...assessmentData, [key]: parseFloat(value) });
  };

  const chartData = [
    { name: 'Body & Health', value: bioHardware },
    { name: 'Inner Beliefs', value: internalOS },
    { name: 'Values', value: culturalSoftware },
    { name: 'Daily Life', value: socialInstance },
    { name: 'Self-Aware', value: consciousUser }
  ];

  const COLORS = ['#a855f7', '#3b82f6', '#10b981', '#f59e0b', '#ef4444'];

  return (
    <div className="space-y-8">
      <LayerPopup layer={selectedLayer} onClose={() => setSelectedLayer(null)} />

      <div>
        <h2 className="text-3xl font-bold mb-2">Rate Your 5 Life Areas</h2>
        <p className="text-gray-300">Drag the sliders or click the circles to rate each area. Click on any area to learn more.</p>
      </div>

      {/* Radar Chart */}
      <div className="bg-slate-800 rounded-2xl p-6 flex items-center justify-center h-96">
        <ResponsiveContainer width="100%" height="100%">
          <RadarChart data={chartData}>
            <PolarGrid stroke="#475569" />
            <PolarAngleAxis dataKey="name" tick={{ fill: '#9ca3af', fontSize: 12 }} />
            <PolarRadiusAxis angle={90} domain={[0, 10]} tick={{ fill: '#9ca3af' }} />
            <Radar name="Your Score" dataKey="value" stroke="#a855f7" fill="#a855f7" fillOpacity={0.6} />
          </RadarChart>
        </ResponsiveContainer>
      </div>

      {/* Interactive Sliders with Clickable Circles */}
      <div className="space-y-6">
        {[
          { key: 'bioHardware', emoji: '🧬', label: 'Body & Health' },
          { key: 'internalOS', emoji: '⚙️', label: 'Inner Beliefs' },
          { key: 'culturalSoftware', emoji: '🌐', label: 'Values & Worldview' },
          { key: 'socialInstance', emoji: '👥', label: 'Daily Life' },
          { key: 'consciousUser', emoji: '💡', label: 'Self-Awareness' }
        ].map(layer => (
          <div key={layer.key} className="bg-slate-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{layer.emoji}</span>
                <h3 className="text-lg font-semibold">{layer.label}</h3>
              </div>
              <button
                onClick={() => setSelectedLayer(layer.key)}
                className="text-gray-400 hover:text-purple-400 transition"
              >
                <Info className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center gap-6">
              <input
                type="range"
                min="0"
                max="10"
                step="0.5"
                value={assessmentData[layer.key]}
                onChange={(e) => updateValue(layer.key, e.target.value)}
                className="flex-1 h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-purple-600"
              />
              <div className="flex items-center gap-3">
                <div 
                  className="w-16 h-16 rounded-full border-4 border-purple-500 flex items-center justify-center text-2xl font-bold cursor-pointer hover:bg-purple-500 hover:bg-opacity-20 transition"
                  onClick={() => setSelectedLayer(layer.key)}
                >
                  {assessmentData[layer.key]}
                </div>
                <span className="text-gray-400">/10</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bar Chart Comparison */}
      <div className="bg-slate-800 rounded-2xl p-6">
        <h3 className="text-lg font-semibold mb-4">Your Current State</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
            <XAxis dataKey="name" tick={{ fill: '#9ca3af' }} />
            <YAxis tick={{ fill: '#9ca3af' }} domain={[0, 10]} />
            <Tooltip 
              contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
              labelStyle={{ color: '#fff' }}
            />
            <Bar dataKey="value" fill="#a855f7" radius={[8, 8, 0, 0]}>
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index]} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default ModernAssessment;
