import React, { useState, useEffect } from 'react';
import { generateInsights } from '../../services/groq';

const Analysis = ({ assessmentData }) => {
  const [insights, setInsights] = useState(null);
  const [loadingInsights, setLoadingInsights] = useState(false);

  if (!assessmentData) return <div>Loading analysis...</div>;

  const { bioHardware = 0, internalOS = 0, culturalSoftware = 0, socialInstance = 0, consciousUser = 0 } = assessmentData;
  
  const allLayers = [bioHardware, internalOS, culturalSoftware, socialInstance, consciousUser];
  const avgScore = (allLayers.reduce((a, b) => a + b, 0) / allLayers.length).toFixed(2);
  const variance = (Math.sqrt(allLayers.reduce((sum, val) => sum + Math.pow(val - avgScore, 2), 0) / allLayers.length)).toFixed(2);
  const harmonyScore = Math.max(0, (10 - variance)).toFixed(2);

  const layerNames = ['Body & Health', 'Inner Beliefs', 'Values & Worldview', 'Daily Life', 'Self-Awareness'];
  const bottleneckIndex = allLayers.indexOf(Math.min(...allLayers));
  const bottleneck = layerNames[bottleneckIndex];

  useEffect(() => {
    const fetchInsights = async () => {
      setLoadingInsights(true);
      const result = await generateInsights(assessmentData);
      setInsights(result);
      setLoadingInsights(false);
    };
    fetchInsights();
  }, [assessmentData]);

  return (
    <div className="analysis-page space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">What Your Assessment Shows</h2>
        <p className="text-gray-300 text-sm">Here's what's working and where you could grow.</p>
      </div>

      <div className="bg-slate-800 rounded-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Your Current State</h3>
        <div className="space-y-3">
          <p><span className="text-purple-400 font-semibold">Overall Life Health:</span> <span className="text-xl font-bold">{avgScore}/10</span> — How well different areas of your life are balanced</p>
          <p><span className="text-purple-400 font-semibold">Life Balance Score:</span> <span className="text-xl font-bold">{harmonyScore}/10</span> — How evenly balanced your 5 areas are (higher = more balanced)</p>
          <p><span className="text-purple-400 font-semibold">Where to Focus First:</span> <span className="text-xl font-bold">{bottleneck}</span> — Your weakest area right now</p>
        </div>
      </div>

      <div className="bg-slate-800 rounded-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Your 5 Life Areas (Detailed)</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-700 rounded p-3">
            <div className="text-sm text-gray-300">🧬 Body & Health</div>
            <div className="text-2xl font-bold text-purple-400 mt-1">{bioHardware}</div>
          </div>
          <div className="bg-slate-700 rounded p-3">
            <div className="text-sm text-gray-300">⚙️ Inner Beliefs</div>
            <div className="text-2xl font-bold text-purple-400 mt-1">{internalOS}</div>
          </div>
          <div className="bg-slate-700 rounded p-3">
            <div className="text-sm text-gray-300">🌐 Values & Worldview</div>
            <div className="text-2xl font-bold text-purple-400 mt-1">{culturalSoftware}</div>
          </div>
          <div className="bg-slate-700 rounded p-3">
            <div className="text-sm text-gray-300">👥 Daily Life</div>
            <div className="text-2xl font-bold text-purple-400 mt-1">{socialInstance}</div>
          </div>
          <div className="bg-slate-700 rounded p-3 col-span-2">
            <div className="text-sm text-gray-300">💡 Self-Awareness</div>
            <div className="text-2xl font-bold text-purple-400 mt-1">{consciousUser}</div>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-purple-900 to-blue-900 rounded-lg p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          💬 Personalized Suggestions
        </h3>
        {loadingInsights ? (
          <p className="text-gray-300 italic">Getting personalized advice for you...</p>
        ) : insights ? (
          <div className="text-white space-y-3 whitespace-pre-wrap text-sm leading-relaxed font-normal">
            {insights}
          </div>
        ) : (
          <p className="text-gray-400">Could not generate suggestions at this time. Try again later.</p>
        )}
      </div>

      <div className="bg-slate-800 rounded-lg p-4 text-xs text-gray-400">
        <p><span className="font-semibold">Tip:</span> The different areas of your life are connected. Improving one often helps the others. Start with your lowest area.</p>
      </div>
    </div>
  );
};

export default Analysis;
