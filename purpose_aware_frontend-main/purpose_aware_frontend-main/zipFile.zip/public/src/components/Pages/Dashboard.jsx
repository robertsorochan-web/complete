import React from 'react';
import MetricCard from '../ui/MetricCard';

const Dashboard = ({ assessmentData }) => {
  const { bioHardware = 0, internalOS = 0, culturalSoftware = 0, socialInstance = 0, consciousUser = 0 } = assessmentData || {};
  
  const allLayers = [bioHardware, internalOS, culturalSoftware, socialInstance, consciousUser];
  const avgScore = (allLayers.reduce((a, b) => a + b, 0) / allLayers.length).toFixed(2);
  const lowestLayer = Math.min(...allLayers);
  const highestLayer = Math.max(...allLayers);
  
  const layerNames = ['Body & Health', 'Inner Beliefs', 'Values & Worldview', 'Daily Life', 'Self-Awareness'];
  const bottleneck = layerNames[allLayers.indexOf(lowestLayer)];
  const strength = layerNames[allLayers.indexOf(highestLayer)];

  return (
    <div className="dashboard-page space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Your Life Overview</h2>
        <p className="text-gray-300 text-sm">Rate yourself across these 5 core areas of life to understand what's working and what needs attention.</p>
      </div>
      
      <div className="bg-blue-900 bg-opacity-30 rounded-lg p-4 mb-4">
        <p className="text-sm text-blue-100"><span className="font-semibold">What this shows:</span> Your overall life health and where you're strongest and weakest. Use this to identify where to focus your energy.</p>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        <MetricCard title="Overall Health" value={avgScore} subtitle="/10" />
        <MetricCard title="Your Strength" value={highestLayer} subtitle={strength} />
        <MetricCard title="Needs Attention" value={lowestLayer} subtitle={bottleneck} />
      </div>

      <div>
        <h3 className="text-lg font-semibold mb-4">Your 5 Life Areas</h3>
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-slate-800 rounded-lg p-4 text-center hover:bg-slate-700 transition">
            <div className="text-2xl mb-2">🧬</div>
            <div className="text-sm text-gray-400">Body & Health</div>
            <div className="text-2xl font-bold text-purple-400 mt-2">{bioHardware}</div>
            <div className="text-xs text-gray-500 mt-1">Sleep, exercise, energy</div>
          </div>
          <div className="bg-slate-800 rounded-lg p-4 text-center hover:bg-slate-700 transition">
            <div className="text-2xl mb-2">⚙️</div>
            <div className="text-sm text-gray-400">Inner Beliefs</div>
            <div className="text-2xl font-bold text-purple-400 mt-2">{internalOS}</div>
            <div className="text-xs text-gray-500 mt-1">Self-talk, confidence</div>
          </div>
          <div className="bg-slate-800 rounded-lg p-4 text-center hover:bg-slate-700 transition">
            <div className="text-2xl mb-2">🌐</div>
            <div className="text-sm text-gray-400">Values & Worldview</div>
            <div className="text-2xl font-bold text-purple-400 mt-2">{culturalSoftware}</div>
            <div className="text-xs text-gray-500 mt-1">What matters to you</div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mt-4">
          <div className="bg-slate-800 rounded-lg p-4 text-center hover:bg-slate-700 transition">
            <div className="text-2xl mb-2">👥</div>
            <div className="text-sm text-gray-400">Daily Life</div>
            <div className="text-2xl font-bold text-purple-400 mt-2">{socialInstance}</div>
            <div className="text-xs text-gray-500 mt-1">Job, relationships, environment</div>
          </div>
          <div className="bg-slate-800 rounded-lg p-4 text-center hover:bg-slate-700 transition">
            <div className="text-2xl mb-2">💡</div>
            <div className="text-sm text-gray-400">Self-Awareness</div>
            <div className="text-2xl font-bold text-purple-400 mt-2">{consciousUser}</div>
            <div className="text-xs text-gray-500 mt-1">Noticing, choosing, control</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
